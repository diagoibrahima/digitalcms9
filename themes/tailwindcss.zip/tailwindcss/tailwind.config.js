module.exports = {
  prefix: 'tw-',
  important: true,
  theme: {
    extend: {},
  },
  variants: {},
  plugins: []
} 
